var searchData=
[
  ['invalid_5fhandle_5fvalue',['INVALID_HANDLE_VALUE',['../kvmlib_8h.html#a5fdc7facea201bfce4ad308105f88d0c',1,'kvmlib.h']]]
];
