var group__kvm__connection =
[
    [ "kvmClose", "group__kvm__connection.html#gacb9bdeb6c9325ee27543b51ee5f3e5b6", null ],
    [ "kvmDeviceMountKmf", "group__kvm__connection.html#ga11c8b93b6bac6226213d34c1302667a2", null ],
    [ "kvmDeviceMountKmfEx", "group__kvm__connection.html#gaa54be9729d75437f8816b12d350344db", null ],
    [ "kvmDeviceOpen", "group__kvm__connection.html#ga0c1b04302a17afc104b513592ddc03b4", null ],
    [ "kvmKmfOpen", "group__kvm__connection.html#gaaaf94697863f27d9754934245f3c0884", null ],
    [ "kvmKmfOpenEx", "group__kvm__connection.html#ga09053e27dfec1aa11abee4acd84e8bc5", null ]
];